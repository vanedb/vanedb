from pathlib import Path
import datetime,json,os,subprocess,time,shutil
O=Path(__file__).parent
D=Path('/Users/anton/code/codex/020-perf-acceptance-20261103T091447Z')
manifest={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'screen':'12 consecutive five-second quiet samples before starting any campaign; individual <=50%, aggregate <=150%, AC. Controller and ps only excluded. Existing per-target checks remain unchanged.','status':'preflight','samples':[],'commands':[['ps','-axo','pid=,ppid=,pcpu=,comm='],['pmset','-g','batt']]}
try:
 streak=0
 for i in range(120):
  rows=[]
  for line in subprocess.check_output(manifest['commands'][0],text=True).splitlines():
   parts=line.split(None,3)
   if len(parts)==4:rows.append({'pid':int(parts[0]),'ppid':int(parts[1]),'cpu':float(parts[2]),'executable':Path(parts[3]).name})
  loads=[p['cpu'] for p in rows if p['pid']!=os.getpid() and p['executable']!='ps'];power=subprocess.check_output(manifest['commands'][1],text=True);quiet=max(loads,default=0)<=50 and sum(loads)<=150;ac="'AC Power'" in power;streak=streak+1 if quiet and ac else 0
  sample={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'excluded_pids':[os.getpid()],'processes':[p for p in rows if p['cpu']>0],'zero_cpu_processes_omitted':sum(p['cpu']==0 for p in rows),'background_max':max(loads,default=0),'background_sum':sum(loads),'quiet':quiet,'power':power,'ac_power':ac,'quiet_streak':streak};manifest['samples'].append(sample);(O/'initial-preflight.json').write_text(json.dumps(manifest,indent=2)+'\n');print(sample['utc'],'AC',ac,'max',sample['background_max'],'sum',round(sample['background_sum'],1),'streak',streak,flush=True)
  if not ac:raise RuntimeError('AC required; do not benchmark')
  if streak>=12:manifest['status']='ready';break
  time.sleep(5)
 else:raise RuntimeError('Host did not settle; do not benchmark')
 manifest['thermal_snapshot']=subprocess.check_output(['pmset','-g','therm'],text=True)
except BaseException as error:
 manifest.update(status='blocked',error=repr(error));raise
finally:
 manifest['ended']=datetime.datetime.now(datetime.timezone.utc).isoformat();(O/'initial-preflight.json').write_text(json.dumps(manifest,indent=2)+'\n')
 for p in O.iterdir():
  if p.is_file():shutil.copy2(p,D/p.name)
